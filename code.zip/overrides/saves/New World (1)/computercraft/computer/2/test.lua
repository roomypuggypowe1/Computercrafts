local web=http.get("https://conect.thepuglas.repl.co")
print (web.readAll())
web.close()
