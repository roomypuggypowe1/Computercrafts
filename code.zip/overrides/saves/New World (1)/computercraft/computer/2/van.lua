while true do
    local response = (http.get("http://localhost:5000/turtle/1")) 
    if response then
        local Move = response.readAll()
        if Move == ("True") then
            turtle.forward()
        end
    end
end
