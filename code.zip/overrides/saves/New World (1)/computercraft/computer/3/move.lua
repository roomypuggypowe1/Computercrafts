modem.open(69)
print("69")
