local computer = peripheral.wrap('left')
computer.open(69)

