while true do 
    turtle.attack()
end

