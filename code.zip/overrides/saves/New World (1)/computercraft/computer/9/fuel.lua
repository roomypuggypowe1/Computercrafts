fuel=turtle.getFuelLevel()
print(fuel)
