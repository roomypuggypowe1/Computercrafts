local computer = peripheral.wrap('left')
computer.open(69)
computer.transmit(69,69,"funny number")
