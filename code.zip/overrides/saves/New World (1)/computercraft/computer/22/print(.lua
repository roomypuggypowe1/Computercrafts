print("HTTP enabled:",http and true or false) > print(http)
