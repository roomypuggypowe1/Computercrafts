Run ?print(http.checkURL("https://example.tweaked.cc/"))
